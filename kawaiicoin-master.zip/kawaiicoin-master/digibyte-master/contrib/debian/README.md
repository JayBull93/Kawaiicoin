
Debian
====================
This directory contains files used to package Kawaiicoind/Kawaiicoin-qt
for Debian-based Linux systems. If you compile Kawaiicoind/Kawaiicoin-qt yourself, there are some useful files here.

## Kawaiicoin: URI support ##


Kawaiicoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install Kawaiicoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your Kawaiicoin-qt binary to `/usr/bin`
and the `../../share/pixmaps/Kawaiicoin128.png` to `/usr/share/pixmaps`

Kawaiicoin-qt.protocol (KDE)

