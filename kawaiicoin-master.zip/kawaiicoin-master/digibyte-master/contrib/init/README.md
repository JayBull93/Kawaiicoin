Sample configuration files for:

SystemD: Kawaiicoind.service
Upstart: Kawaiicoind.conf
OpenRC:  Kawaiicoind.openrc
         Kawaiicoind.openrcconf
CentOS:  Kawaiicoind.init
OS X:    org.Kawaiicoin.Kawaiicoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
